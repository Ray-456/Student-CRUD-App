//Defines the Mongoose schema for the Student model.
const mongoose = require('mongoose');


// The schema includes the following fields:
const studentSchema = new mongoose.Schema({
  // firstName: The student's first name (required).
  firstName: { type: String, required: true },
  // lastName: The student's last name (required).
  lastName:  { type: String, required: true },
  // email: The student's email address (required, unique).
  email:     { type: String, required: true, unique: true },
  // age: The student's age (required).
  age:       { type: Number, required: true }
});



// Exports the compiled Student model for use in the application.
// This allows other parts of the application to interact with the Student collection in MongoDB.
module.exports = mongoose.model('Student', studentSchema);
