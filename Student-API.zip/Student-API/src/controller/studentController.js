const Student = require('../models/student.schema.js');

// Create
exports.createStudent = async (req, res) => {
  try {
    const { firstName, lastName, email, age } = req.body;
    if (!firstName || !lastName || !email || !age)
      return res.status(400).json({ error: "All fields are required" });

    const exists = await Student.findOne({ email });
    if (exists)
      return res.status(409).json({ error: "Email already exists" });

    const student = await Student.create({ firstName, lastName, email, age });
    res.status(201).json(student);
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
};

// Read all with pagination and filter

exports.getAllStudents = async (req, res) => {
  try {
    const { page = 1, limit = 10, lastName } = req.query;

    const query = {};
    if (lastName) {
      query.lastName = new RegExp(`^${lastName}$`, 'i'); // case-insensitive
    }

    const students = await Student.find(query)
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    res.status(200).json(students);
  } catch (error) {
    console.error('Get All Error:', error.message);
    res.status(500).json({ error: 'Server error' });
  }
};

exports.getStudentCount = async (req, res) => {
  try {
    const count = await Student.countDocuments();
    res.json({ count });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
};


// Update
exports.updateStudent = async (req, res) => {
  try {
    const updated = await Student.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    if (!updated)
      return res.status(404).json({ error: "Student not found" });

    res.json(updated);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error" });
  }
};

// Delete
exports.deleteStudent = async (req, res) => {
  try {
    const deleted = await Student.findByIdAndDelete(req.params.id);
    if (!deleted)
      return res.status(404).json({ error: "Student not found" });

    res.json({ message: "Deleted", id: deleted._id });
  } catch (err) {
    res.status(500).json({ error: "Server error" });
  }
};
